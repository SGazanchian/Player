#ifndef _BEEP_H_
#define _BEEP_H_

int beep (float freq , int len);

#endif